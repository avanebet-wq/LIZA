package com.example.girl

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.view.View

enum class Emotion { HAPPY, NEUTRAL, SAD, SLEEPY, SHY }

/** Оригинальная девочка, нарисованная кодом (без картинок). Логический размер 160x220. */
class GirlView(context: Context) : View(context) {

    var emotion: Emotion = Emotion.HAPPY
        set(value) {
            field = value
            invalidate()
        }

    private val density = context.resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val path = Path()
    private val handler = Handler(Looper.getMainLooper())
    private var blinking = false
    private var bob = 0f
    private var bobAnimator: ValueAnimator? = null

    private val hair = 0xFF8E6BD8.toInt()
    private val hairDark = 0xFF7656C4.toInt()
    private val skin = 0xFFFFE3D3.toInt()
    private val dress = 0xFFFF8FB1.toInt()
    private val pink = 0xFFFF5C8A.toInt()
    private val ink = 0xFF3B2A6B.toInt()
    private val iris = 0xFF7C6CF0.toInt()
    private val mouthColor = 0xFFC2455F.toInt()
    private val white = 0xFFFFFFFF.toInt()

    private val blinkRunnable = object : Runnable {
        override fun run() {
            blinking = true
            invalidate()
            handler.postDelayed({
                blinking = false
                invalidate()
            }, 150)
            handler.postDelayed(this, 3500)
        }
    }

    fun nextEmotion() {
        val all = Emotion.values()
        emotion = all[(emotion.ordinal + 1) % all.size]
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        bobAnimator = ValueAnimator.ofFloat(0f, 5f).apply {
            duration = 1100
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            addUpdateListener {
                bob = it.animatedValue as Float
                invalidate()
            }
            start()
        }
        handler.postDelayed(blinkRunnable, 2000)
    }

    override fun onDetachedFromWindow() {
        bobAnimator?.cancel()
        handler.removeCallbacksAndMessages(null)
        super.onDetachedFromWindow()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension((W * density).toInt(), (H * density).toInt())
    }

    private fun fill(color: Int) {
        paint.style = Paint.Style.FILL
        paint.color = color
    }

    private fun line(color: Int, width: Float) {
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = width
        paint.strokeCap = Paint.Cap.ROUND
        paint.color = color
    }

    override fun onDraw(c: Canvas) {
        c.save()
        c.scale(width / W, height / H)
        c.translate(0f, bob)

        // Волосы сзади
        fill(hairDark)
        rect.set(18f, 18f, 142f, 150f)
        c.drawOval(rect, paint)
        rect.set(24f, 80f, 136f, 196f)
        c.drawRoundRect(rect, 30f, 30f, paint)

        // Платье
        fill(dress)
        path.reset()
        path.moveTo(58f, 148f)
        path.lineTo(102f, 148f)
        path.lineTo(116f, 208f)
        path.lineTo(44f, 208f)
        path.close()
        c.drawPath(path, paint)

        // Воротник и бантик
        fill(white)
        path.reset()
        path.moveTo(68f, 148f)
        path.lineTo(92f, 148f)
        path.lineTo(80f, 164f)
        path.close()
        c.drawPath(path, paint)
        fill(pink)
        c.drawCircle(80f, 166f, 5f, paint)

        // Шея и голова
        fill(skin)
        rect.set(72f, 136f, 88f, 154f)
        c.drawRect(rect, paint)
        c.drawCircle(80f, 88f, 50f, paint)

        // Чёлка
        fill(hair)
        rect.set(28f, 38f, 132f, 118f)
        c.drawArc(rect, 180f, 180f, true, paint)
        path.reset()
        path.moveTo(30f, 78f)
        path.lineTo(48f, 96f)
        path.lineTo(62f, 78f)
        path.moveTo(58f, 78f)
        path.lineTo(78f, 98f)
        path.lineTo(98f, 78f)
        path.moveTo(96f, 78f)
        path.lineTo(112f, 96f)
        path.lineTo(130f, 78f)
        c.drawPath(path, paint)

        // Бантики
        fill(pink)
        c.drawCircle(34f, 52f, 7f, paint)
        c.drawCircle(126f, 52f, 7f, paint)

        // Румянец
        fill(pink)
        paint.alpha = if (emotion == Emotion.SHY) 230 else 130
        rect.set(37f, 113f, 55f, 123f)
        c.drawOval(rect, paint)
        rect.set(105f, 113f, 123f, 123f)
        c.drawOval(rect, paint)
        paint.alpha = 255

        drawEye(c, 60f, 104f)
        drawEye(c, 100f, 104f)
        drawMouth(c)

        if (emotion == Emotion.SLEEPY) {
            fill(iris)
            paint.textSize = 20f
            c.drawText("z", 120f, 36f, paint)
            paint.textSize = 14f
            c.drawText("z", 134f, 22f, paint)
        }

        c.restore()
    }

    private fun drawEye(c: Canvas, cx: Float, cy: Float) {
        when {
            emotion == Emotion.HAPPY -> {
                line(ink, 3.5f)
                rect.set(cx - 10f, cy - 6f, cx + 10f, cy + 10f)
                c.drawArc(rect, 200f, 140f, false, paint)
            }
            emotion == Emotion.SLEEPY || blinking -> {
                line(ink, 3.5f)
                rect.set(cx - 10f, cy - 8f, cx + 10f, cy + 6f)
                c.drawArc(rect, 20f, 140f, false, paint)
            }
            else -> {
                fill(ink)
                rect.set(cx - 9f, cy - 12f, cx + 9f, cy + 12f)
                c.drawOval(rect, paint)
                fill(iris)
                rect.set(cx - 7f, cy - 8f, cx + 7f, cy + 11f)
                c.drawOval(rect, paint)
                fill(white)
                c.drawCircle(cx - 3f, cy - 4f, 4f, paint)
                c.drawCircle(cx + 3f, cy + 5f, 2f, paint)
            }
        }
        if (emotion == Emotion.SAD) {
            line(ink, 2.5f)
            if (cx < 80f) c.drawLine(cx - 10f, cy - 16f, cx + 8f, cy - 22f, paint)
            else c.drawLine(cx - 8f, cy - 22f, cx + 10f, cy - 16f, paint)
        }
    }

    private fun drawMouth(c: Canvas) {
        when (emotion) {
            Emotion.HAPPY -> {
                fill(mouthColor)
                rect.set(70f, 114f, 90f, 130f)
                c.drawArc(rect, 0f, 180f, true, paint)
            }
            Emotion.NEUTRAL -> {
                line(mouthColor, 2.5f)
                rect.set(73f, 114f, 87f, 126f)
                c.drawArc(rect, 20f, 140f, false, paint)
            }
            Emotion.SAD -> {
                line(mouthColor, 2.5f)
                rect.set(73f, 122f, 87f, 134f)
                c.drawArc(rect, 200f, 140f, false, paint)
            }
            Emotion.SLEEPY -> {
                fill(mouthColor)
                rect.set(77f, 118f, 83f, 125f)
                c.drawOval(rect, paint)
            }
            Emotion.SHY -> {
                line(mouthColor, 2.5f)
                rect.set(71f, 118f, 80f, 127f)
                c.drawArc(rect, 0f, 180f, false, paint)
                rect.set(80f, 118f, 89f, 127f)
                c.drawArc(rect, 0f, 180f, false, paint)
            }
        }
    }

    companion object {
        private const val W = 160f
        private const val H = 220f
    }
}
