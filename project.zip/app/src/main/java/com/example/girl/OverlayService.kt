package com.example.girl

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewConfiguration
import android.view.WindowManager
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.random.Random

class OverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var audio: AudioManager
    private lateinit var params: WindowManager.LayoutParams
    private var ghost: GhostView? = null
    private val handler = Handler(Looper.getMainLooper())

    // Положение, скорость и цель в пикселях
    private var px = 300f
    private var py = 500f
    private var vx = 0f
    private var vy = 0f
    private var tx = 300f
    private var ty = 500f
    private var lastPx = 300f
    private var lastPy = 500f
    private var smVx = 0f
    private var smVy = 0f

    private var nextTargetAt = 0L
    private var resumeAt = 0L
    private var lastFrameNs = 0L
    private var dragging = false
    private var musicOn = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        if (ghost == null) showGhost()
        return START_STICKY
    }

    private fun startAsForeground() {
        val channelId = "girl_overlay"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(channelId, "Призрак на экране", NotificationManager.IMPORTANCE_LOW)
        )
        val notification = Notification.Builder(this, channelId)
            .setContentTitle("Призрак на экране")
            .setContentText("Чтобы убрать, открой приложение и нажми «Убрать призрака»")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, notification)
        }
    }

    private fun showGhost() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        audio = getSystemService(AUDIO_SERVICE) as AudioManager
        val view = GhostView(this)
        val dm = resources.displayMetrics

        px = dm.widthPixels / 2f
        py = dm.heightPixels / 3f
        tx = px
        ty = py
        lastPx = px
        lastPy = py

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = px.toInt()
            y = py.toInt()
        }

        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var startPx = 0f
        var startPy = 0f
        var touchX = 0f
        var touchY = 0f
        var moved = false

        view.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    dragging = true
                    startPx = px
                    startPy = py
                    touchX = event.rawX
                    touchY = event.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - touchX
                    val dy = event.rawY - touchY
                    if (abs(dx) > slop || abs(dy) > slop) moved = true
                    if (moved) {
                        val m = resources.displayMetrics
                        px = (startPx + dx).coerceIn(0f, (m.widthPixels - v.width).toFloat())
                        py = (startPy + dy).coerceIn(0f, (m.heightPixels - v.height).toFloat())
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    dragging = false
                    // После отпускания призрак немного летит по инерции, потом снова гуляет сам
                    vx = smVx * 0.5f
                    vy = smVy * 0.5f
                    tx = px
                    ty = py
                    resumeAt = SystemClock.uptimeMillis() + 1200
                    nextTargetAt = resumeAt
                    if (event.action == MotionEvent.ACTION_UP && !moved) view.nextEmotion()
                    true
                }
                else -> false
            }
        }

        windowManager.addView(view, params)
        ghost = view

        Choreographer.getInstance().postFrameCallback(frame)
        handler.post(musicCheck)
    }

    // Раз в секунду проверяем, играет ли на телефоне музыка или видео
    private val musicCheck = object : Runnable {
        override fun run() {
            musicOn = audio.isMusicActive
            ghost?.dancing = musicOn
            handler.postDelayed(this, 1000)
        }
    }

    private fun pickTarget(now: Long, w: Float, h: Float) {
        val dm = resources.displayMetrics
        val d = dm.density
        val maxX = dm.widthPixels - w
        val minY = 24f * d
        val maxY = dm.heightPixels - h - 56f * d

        if (Random.nextFloat() < 0.6f) {
            // Плавает рядом с тем местом, где уже находится
            val r = 150f * d
            tx = (px + Random.nextFloat() * 2f * r - r).coerceIn(0f, maxX)
            ty = (py + Random.nextFloat() * 2f * r - r).coerceIn(minY, maxY)
        } else {
            // Перелетает на другую часть экрана
            tx = Random.nextFloat() * maxX
            ty = minY + Random.nextFloat() * (maxY - minY)
        }
        nextTargetAt = now + if (musicOn) Random.nextLong(1200L, 2200L) else Random.nextLong(2500L, 5000L)
    }

    private val frame = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            val g = ghost ?: return
            if (g.width == 0) {
                Choreographer.getInstance().postFrameCallback(this)
                return
            }
            val dm = resources.displayMetrics
            val d = dm.density
            val w = g.width.toFloat()
            val h = g.height.toFloat()

            if (lastFrameNs == 0L) lastFrameNs = frameTimeNanos
            val dt = ((frameTimeNanos - lastFrameNs) / 1_000_000_000f).coerceIn(0.001f, 0.05f)
            lastFrameNs = frameTimeNanos
            val now = SystemClock.uptimeMillis()

            if (!dragging) {
                if (now >= resumeAt) {
                    if (now >= nextTargetAt || hypot(tx - px, ty - py) < w * 0.3f) pickTarget(now, w, h)
                    // Пружина с лёгким недодемпфированием: полёт получается плавным и парящим
                    val k = if (musicOn) 5.5f else 2.6f
                    val c = if (musicOn) 2.6f else 1.7f
                    vx += ((tx - px) * k - vx * c) * dt
                    vy += ((ty - py) * k - vy * c) * dt
                } else {
                    vx -= vx * 2.5f * dt
                    vy -= vy * 2.5f * dt
                }

                val maxV = 800f * d
                val sp = hypot(vx, vy)
                if (sp > maxV) {
                    vx *= maxV / sp
                    vy *= maxV / sp
                }
                px += vx * dt
                py += vy * dt

                val maxX = dm.widthPixels - w
                val minY = 24f * d
                val maxY = dm.heightPixels - h - 56f * d
                if (px < 0f) { px = 0f; vx = abs(vx) * 0.4f }
                else if (px > maxX) { px = maxX; vx = -abs(vx) * 0.4f }
                if (py < minY) { py = minY; vy = abs(vy) * 0.4f }
                else if (py > maxY) { py = maxY; vy = -abs(vy) * 0.4f }
            }

            // Реальная скорость (и при полёте, и при перетаскивании) двигает подол и наклон
            smVx += ((px - lastPx) / dt - smVx) * 0.25f
            smVy += ((py - lastPy) / dt - smVy) * 0.25f
            lastPx = px
            lastPy = py
            g.setMotion(smVx / d, smVy / d)

            val ix = px.toInt()
            val iy = py.toInt()
            if (ix != params.x || iy != params.y) {
                params.x = ix
                params.y = iy
                try {
                    windowManager.updateViewLayout(g, params)
                } catch (e: Exception) {
                    // окно уже убрано
                }
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    override fun onDestroy() {
        Choreographer.getInstance().removeFrameCallback(frame)
        handler.removeCallbacksAndMessages(null)
        ghost?.let { windowManager.removeView(it) }
        ghost = null
        super.onDestroy()
    }
}
