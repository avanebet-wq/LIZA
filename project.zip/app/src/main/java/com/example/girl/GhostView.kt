package com.example.girl

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.sin

enum class Emotion { HAPPY, NEUTRAL, SAD, SLEEPY, SHY }

/** Оригинальный призрак, нарисованный кодом. Логический размер 110x126. */
class GhostView(context: Context) : View(context) {

    var emotion: Emotion = Emotion.HAPPY
        set(value) {
            field = value
            invalidate()
        }

    /** Включается, когда на телефоне играет музыка или видео. */
    var dancing: Boolean = false
        set(value) {
            if (field != value) {
                field = value
                invalidate()
            }
        }

    /** Скорость полёта в dp/с. Ею управляет сервис. */
    fun setMotion(vxDp: Float, vyDp: Float) {
        mvx = vxDp
        mvy = vyDp
        invalidate()
    }

    private val shown: Emotion get() = if (dancing) Emotion.HAPPY else emotion

    private val density = context.resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val body = Path()
    private val handler = Handler(Looper.getMainLooper())
    private var blinking = false
    private var t = 0f
    private var phase = 0f
    private var lastNs = 0L
    private var mvx = 0f
    private var mvy = 0f
    private var animator: ValueAnimator? = null

    private val white = 0xFFFFFFFF.toInt()
    private val purple = 0xFFB04AE0.toInt()
    private val glow = 0xFFB07CFF.toInt()
    private val ink = 0xFF2A1050.toInt()
    private val pink = 0xFFFF8FD0.toInt()
    private val spark = 0xFFE3C8FF.toInt()
    private val shader = LinearGradient(0f, 60f, 0f, 104f, white, purple, Shader.TileMode.CLAMP)

    private val blinkRunnable = object : Runnable {
        override fun run() {
            blinking = true
            invalidate()
            handler.postDelayed({
                blinking = false
                invalidate()
            }, 150)
            handler.postDelayed(this, 3500)
        }
    }

    fun nextEmotion() {
        val all = Emotion.values()
        emotion = all[(emotion.ordinal + 1) % all.size]
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 2400
            interpolator = LinearInterpolator()
            repeatCount = ValueAnimator.INFINITE
            addUpdateListener {
                t = it.animatedValue as Float
                invalidate()
            }
            start()
        }
        handler.postDelayed(blinkRunnable, 2000)
    }

    override fun onDetachedFromWindow() {
        animator?.cancel()
        handler.removeCallbacksAndMessages(null)
        super.onDetachedFromWindow()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension((W * SCALE * density).toInt(), (H * SCALE * density).toInt())
    }

    private fun sinF(x: Float): Float = sin(x)

    private fun fill(color: Int) {
        paint.style = Paint.Style.FILL
        paint.color = color
    }

    private fun line(color: Int, width: Float) {
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = width
        paint.strokeCap = Paint.Cap.ROUND
        paint.strokeJoin = Paint.Join.ROUND
        paint.color = color
    }

    private fun sparkle(c: Canvas, x: Float, y: Float, r: Float, ph: Float) {
        line(spark, 1.6f)
        paint.alpha = (130 + 120 * sinF(TWO_PI * (t + ph))).toInt().coerceIn(0, 255)
        c.drawLine(x - r, y, x + r, y, paint)
        c.drawLine(x, y - r, x, y + r, paint)
        paint.alpha = 255
    }

    private fun shear(y: Float): Float {
        val s = ((y - 50f) / 50f).coerceAtLeast(0f)
        return s * s
    }

    /** Тело: купол сверху, а низ колышется волной и отстаёт от направления полёта. */
    private fun buildBody(speed: Float) {
        val lagX = -(mvx / 500f).coerceIn(-1f, 1f) * 10f
        val lagY = -(mvy / 500f).coerceIn(-1f, 1f) * 6f
        val amp = 3.5f + 4.5f * speed

        body.reset()
        body.moveTo(16f, 44f)
        rect.set(16f, 10f, 84f, 78f)
        body.arcTo(rect, 180f, 180f, false)

        var y = 52f
        while (y <= 84f) {
            val s = shear(y)
            body.lineTo(84f + lagX * s, y + lagY * s)
            y += 8f
        }

        val n = 24
        for (i in 0..n) {
            val u = i / n.toFloat()
            val a = TWO_PI * 2.5f * u - phase
            val x = 84f - 68f * u + lagX + 2.2f * speed * sinF(a + 1.3f)
            val yy = 95f + amp * sinF(a) + lagY
            body.lineTo(x, yy)
        }

        y = 84f
        while (y >= 52f) {
            val s = shear(y)
            body.lineTo(16f + lagX * s, y + lagY * s)
            y -= 8f
        }
        body.close()
    }

    override fun onDraw(c: Canvas) {
        val nowNs = System.nanoTime()
        val dt = if (lastNs == 0L) 0f else ((nowNs - lastNs) / 1e9f).coerceAtMost(0.05f)
        lastNs = nowNs

        val speed = (hypot(mvx, mvy) / 600f).coerceIn(0f, 1f)
        phase += dt * (1.4f + 7f * speed + if (dancing) 2f else 0f)

        // Ритм танца: 2.2 удара в секунду. Окно в 100 секунд даёт целое число ударов, шва нет.
        val beat = (nowNs % 100_000_000_000L) / 1e9f * 2.2f
        val hop = if (dancing) -6f * abs(sinF(PI.toFloat() * beat)) else 0f
        val sway = if (dancing) 10f * sinF(PI.toFloat() * beat) else 0f
        val bob = 3f * sinF(TWO_PI * t)
        val lean = (mvx / 500f).coerceIn(-1f, 1f) * 14f + sway

        buildBody(speed)

        c.save()
        c.scale(width / W, height / H)
        c.translate(5f, 10f + bob + hop)
        c.rotate(lean, 50f, 50f)

        // Искорки
        sparkle(c, 8f, 24f, 4f, 0f)
        sparkle(c, 92f, 40f, 3f, 0.33f)
        sparkle(c, 6f, 74f, 3f, 0.66f)
        sparkle(c, 93f, 82f, 4f, 0.5f)

        // Свечение
        line(glow, 8f)
        paint.alpha = 70
        c.drawPath(body, paint)
        paint.alpha = 255

        // Тело с фиолетовым низом
        fill(white)
        paint.shader = shader
        c.drawPath(body, paint)
        paint.shader = null

        // Лицо чуть смотрит по ходу полёта
        c.save()
        c.translate((mvx / 500f).coerceIn(-1f, 1f) * 2.5f, (mvy / 500f).coerceIn(-1f, 1f) * 1.5f)

        val blushAlpha = when (shown) {
            Emotion.SHY -> 220
            Emotion.HAPPY -> 110
            else -> 0
        }
        if (blushAlpha > 0) {
            fill(pink)
            paint.alpha = blushAlpha
            rect.set(24f, 58f, 34f, 64f)
            c.drawOval(rect, paint)
            rect.set(66f, 58f, 76f, 64f)
            c.drawOval(rect, paint)
            paint.alpha = 255
        }

        drawEye(c, 38f, 50f)
        drawEye(c, 62f, 50f)
        drawMouth(c)
        c.restore()

        if (shown == Emotion.SLEEPY) {
            fill(spark)
            paint.textSize = 14f
            c.drawText("z", 78f, 16f, paint)
            paint.textSize = 10f
            c.drawText("z", 88f, 8f, paint)
        }

        if (dancing) {
            for (k in 0..1) {
                val p = ((nowNs % 100_000_000_000L) / 1e9f * 0.6f + k * 0.5f) % 1f
                val x = 88f + 8f * k + 4f * sinF(TWO_PI * p * 1.5f)
                val y = 64f - 54f * p
                val a = (255 * (1f - p)).toInt().coerceIn(0, 255)
                fill(spark)
                paint.alpha = a
                rect.set(x - 3f, y - 2.2f, x + 3f, y + 2.2f)
                c.drawOval(rect, paint)
                line(spark, 1.6f)
                paint.alpha = a
                c.drawLine(x + 2.6f, y, x + 2.6f, y - 9f, paint)
                c.drawLine(x + 2.6f, y - 9f, x + 6f, y - 6f, paint)
                paint.alpha = 255
            }
        }

        c.restore()
    }

    private fun drawEye(c: Canvas, cx: Float, cy: Float) {
        when {
            shown == Emotion.HAPPY -> {
                line(ink, 2.8f)
                rect.set(cx - 6f, cy - 4f, cx + 6f, cy + 7f)
                c.drawArc(rect, 200f, 140f, false, paint)
            }
            shown == Emotion.SLEEPY || blinking -> {
                line(ink, 2.8f)
                rect.set(cx - 6f, cy - 6f, cx + 6f, cy + 3f)
                c.drawArc(rect, 20f, 140f, false, paint)
            }
            else -> {
                fill(ink)
                rect.set(cx - 5.5f, cy - 8f, cx + 5.5f, cy + 8f)
                c.drawOval(rect, paint)
                fill(white)
                c.drawCircle(cx - 1.8f, cy - 3.5f, 1.8f, paint)
            }
        }
        if (shown == Emotion.SAD) {
            line(ink, 2f)
            if (cx < 50f) c.drawLine(cx - 6f, cy - 12f, cx + 5f, cy - 16f, paint)
            else c.drawLine(cx - 5f, cy - 16f, cx + 6f, cy - 12f, paint)
        }
    }

    private fun drawMouth(c: Canvas) {
        when (shown) {
            Emotion.HAPPY -> {
                fill(ink)
                rect.set(44f, 62f, 56f, 74f)
                c.drawArc(rect, 0f, 180f, true, paint)
            }
            Emotion.NEUTRAL -> Unit
            Emotion.SAD -> {
                line(ink, 2f)
                rect.set(44f, 70f, 56f, 78f)
                c.drawArc(rect, 200f, 140f, false, paint)
            }
            Emotion.SLEEPY -> {
                fill(ink)
                rect.set(47f, 64f, 53f, 70f)
                c.drawOval(rect, paint)
            }
            Emotion.SHY -> {
                line(ink, 2f)
                rect.set(42f, 64f, 50f, 71f)
                c.drawArc(rect, 0f, 180f, false, paint)
                rect.set(50f, 64f, 58f, 71f)
                c.drawArc(rect, 0f, 180f, false, paint)
            }
        }
    }

    companion object {
        private const val W = 110f
        private const val H = 126f
        private const val TWO_PI = (2.0 * PI).toFloat()

        /** Размер на экране: W x H dp умножить на SCALE. Меняй это число, чтобы сделать больше или меньше. */
        private const val SCALE = 0.6f
    }
}
