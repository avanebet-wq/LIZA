package com.example.girl

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.sin

enum class Emotion { HAPPY, NEUTRAL, SAD, SLEEPY, SHY }

/** Оригинальный призрак, нарисованный кодом. Логический размер 100x110. */
class GhostView(context: Context) : View(context) {

    var emotion: Emotion = Emotion.HAPPY
        set(value) {
            field = value
            invalidate()
        }

    private val density = context.resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val body = Path()
    private val handler = Handler(Looper.getMainLooper())
    private var blinking = false
    private var t = 0f
    private var animator: ValueAnimator? = null

    private val white = 0xFFFFFFFF.toInt()
    private val purple = 0xFFB04AE0.toInt()
    private val glow = 0xFFB07CFF.toInt()
    private val ink = 0xFF2A1050.toInt()
    private val pink = 0xFFFF8FD0.toInt()
    private val spark = 0xFFE3C8FF.toInt()
    private val shader = LinearGradient(0f, 60f, 0f, 104f, white, purple, Shader.TileMode.CLAMP)

    init {
        body.moveTo(16f, 92f)
        body.lineTo(16f, 44f)
        rect.set(16f, 10f, 84f, 78f)
        body.arcTo(rect, 180f, 180f, false)
        body.lineTo(84f, 92f)
        body.quadTo(75.5f, 108f, 67f, 92f)
        body.quadTo(58.5f, 108f, 50f, 92f)
        body.quadTo(41.5f, 108f, 33f, 92f)
        body.quadTo(24.5f, 108f, 16f, 92f)
        body.close()
    }

    private val blinkRunnable = object : Runnable {
        override fun run() {
            blinking = true
            invalidate()
            handler.postDelayed({
                blinking = false
                invalidate()
            }, 150)
            handler.postDelayed(this, 3500)
        }
    }

    fun nextEmotion() {
        val all = Emotion.values()
        emotion = all[(emotion.ordinal + 1) % all.size]
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 2400
            interpolator = LinearInterpolator()
            repeatCount = ValueAnimator.INFINITE
            addUpdateListener {
                t = it.animatedValue as Float
                invalidate()
            }
            start()
        }
        handler.postDelayed(blinkRunnable, 2000)
    }

    override fun onDetachedFromWindow() {
        animator?.cancel()
        handler.removeCallbacksAndMessages(null)
        super.onDetachedFromWindow()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension((W * SCALE * density).toInt(), (H * SCALE * density).toInt())
    }

    private fun fill(color: Int) {
        paint.style = Paint.Style.FILL
        paint.color = color
    }

    private fun line(color: Int, width: Float) {
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = width
        paint.strokeCap = Paint.Cap.ROUND
        paint.color = color
    }

    private fun sparkle(c: Canvas, x: Float, y: Float, r: Float, phase: Float) {
        line(spark, 1.6f)
        paint.alpha = (130 + 120 * sin(2 * PI * (t + phase))).toInt().coerceIn(0, 255)
        c.drawLine(x - r, y, x + r, y, paint)
        c.drawLine(x, y - r, x, y + r, paint)
        paint.alpha = 255
    }

    override fun onDraw(c: Canvas) {
        c.save()
        c.scale(width / W, height / H)
        c.translate(0f, (3 * sin(2 * PI * t)).toFloat())

        // Искорки
        sparkle(c, 8f, 24f, 4f, 0f)
        sparkle(c, 92f, 40f, 3f, 0.33f)
        sparkle(c, 6f, 74f, 3f, 0.66f)
        sparkle(c, 93f, 82f, 4f, 0.5f)

        // Свечение
        line(glow, 8f)
        paint.alpha = 70
        c.drawPath(body, paint)
        paint.alpha = 255

        // Тело с фиолетовым низом
        fill(white)
        paint.shader = shader
        c.drawPath(body, paint)
        paint.shader = null

        // Румянец
        val blushAlpha = when (emotion) {
            Emotion.SHY -> 220
            Emotion.HAPPY -> 110
            else -> 0
        }
        if (blushAlpha > 0) {
            fill(pink)
            paint.alpha = blushAlpha
            rect.set(24f, 58f, 34f, 64f)
            c.drawOval(rect, paint)
            rect.set(66f, 58f, 76f, 64f)
            c.drawOval(rect, paint)
            paint.alpha = 255
        }

        drawEye(c, 38f, 50f)
        drawEye(c, 62f, 50f)
        drawMouth(c)

        if (emotion == Emotion.SLEEPY) {
            fill(spark)
            paint.textSize = 14f
            c.drawText("z", 78f, 16f, paint)
            paint.textSize = 10f
            c.drawText("z", 88f, 8f, paint)
        }

        c.restore()
    }

    private fun drawEye(c: Canvas, cx: Float, cy: Float) {
        when {
            emotion == Emotion.HAPPY -> {
                line(ink, 2.8f)
                rect.set(cx - 6f, cy - 4f, cx + 6f, cy + 7f)
                c.drawArc(rect, 200f, 140f, false, paint)
            }
            emotion == Emotion.SLEEPY || blinking -> {
                line(ink, 2.8f)
                rect.set(cx - 6f, cy - 6f, cx + 6f, cy + 3f)
                c.drawArc(rect, 20f, 140f, false, paint)
            }
            else -> {
                fill(ink)
                rect.set(cx - 5.5f, cy - 8f, cx + 5.5f, cy + 8f)
                c.drawOval(rect, paint)
                fill(white)
                c.drawCircle(cx - 1.8f, cy - 3.5f, 1.8f, paint)
            }
        }
        if (emotion == Emotion.SAD) {
            line(ink, 2f)
            if (cx < 50f) c.drawLine(cx - 6f, cy - 12f, cx + 5f, cy - 16f, paint)
            else c.drawLine(cx - 5f, cy - 16f, cx + 6f, cy - 12f, paint)
        }
    }

    private fun drawMouth(c: Canvas) {
        when (emotion) {
            Emotion.HAPPY -> {
                fill(ink)
                rect.set(44f, 62f, 56f, 74f)
                c.drawArc(rect, 0f, 180f, true, paint)
            }
            Emotion.NEUTRAL -> Unit
            Emotion.SAD -> {
                line(ink, 2f)
                rect.set(44f, 70f, 56f, 78f)
                c.drawArc(rect, 200f, 140f, false, paint)
            }
            Emotion.SLEEPY -> {
                fill(ink)
                rect.set(47f, 64f, 53f, 70f)
                c.drawOval(rect, paint)
            }
            Emotion.SHY -> {
                line(ink, 2f)
                rect.set(42f, 64f, 50f, 71f)
                c.drawArc(rect, 0f, 180f, false, paint)
                rect.set(50f, 64f, 58f, 71f)
                c.drawArc(rect, 0f, 180f, false, paint)
            }
        }
    }

    companion object {
        private const val W = 100f
        private const val H = 110f
        /** Размер на экране: 100x110 dp * SCALE. Меняй это число, чтобы сделать больше или меньше. */
        private const val SCALE = 0.85f
    }
}
